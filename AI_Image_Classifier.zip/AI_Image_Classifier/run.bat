@echo off
title AI Image Classifier - Auto Setup and Runner
echo ==============================================================
echo     AI Image Classifier - Automated Setup and Runner
echo ==============================================================
echo.

:: Check Python installation
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python was not found on your system!
    echo Please download and install Python 3.8+ from https://www.python.org/
    pause
    exit /b 1
)

:: Create virtual environment if it doesn't exist
if not exist venv (
    echo [INFO] Creating Python virtual environment (venv)...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create virtual environment!
        pause
        exit /b 1
    )
)

:: Activate virtual environment
echo [INFO] Activating virtual environment...
call venv\Scripts\activate
if %errorlevel% neq 0 (
    echo [ERROR] Failed to activate virtual environment!
    pause
    exit /b 1
)

:: Install requirements
echo [INFO] Installing/checking dependencies (this may take a minute)...
python -m pip install --upgrade pip >nul 2>nul
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install dependencies!
    pause
    exit /b 1
)

:: Check for model file
if not exist model\mobilenet_model.h5 (
    echo.
    echo --------------------------------------------------------------
    echo [NOTICE] Local trained model file (model/mobilenet_model.h5) was not found.
    echo.
    echo Options:
    echo   [1] Start Web App immediately (uses high-accuracy ImageNet mapping)
    echo   [2] Train local model first (takes 10-30 minutes, requires TensorFlow)
    echo --------------------------------------------------------------
    echo.
    set /p choice="Enter your choice (1 or 2, default is 1): "
    
    if "%choice%"=="2" (
        echo [INFO] Starting training...
        python model/train_model.py
        if %errorlevel% neq 0 (
            echo [ERROR] Training failed!
            pause
            exit /b 1
        )
    ) else (
        echo [INFO] Skipping training. Running web app directly using ImageNet mapping...
    )
)

echo.
echo [INFO] Starting Flask web application...
echo Open your browser and go to: http://localhost:5000
echo.
python app.py
pause
