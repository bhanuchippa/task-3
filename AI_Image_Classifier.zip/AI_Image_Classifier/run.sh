#!/bin/bash

echo "=============================================================="
echo "    AI Image Classifier - Automated Setup and Runner"
echo "=============================================================="
echo

# Check Python installation
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 was not found on your system!"
    echo "Please download and install Python 3.8+ from https://www.python.org/"
    exit 1
fi

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "[INFO] Creating Python virtual environment (venv)..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to create virtual environment!"
        exit 1
    fi
fi

# Activate virtual environment
echo "[INFO] Activating virtual environment..."
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo "[ERROR] Failed to activate virtual environment!"
    exit 1
fi

# Install requirements
echo "[INFO] Installing/checking dependencies (this may take a minute)..."
python3 -m pip install --upgrade pip >/dev/null 2>&1
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "[ERROR] Failed to install dependencies!"
    exit 1
fi

# Check for model file
if [ ! -f "model/mobilenet_model.h5" ]; then
    echo
    echo "--------------------------------------------------------------"
    echo "[NOTICE] Local trained model file (model/mobilenet_model.h5) was not found."
    echo
    echo "Options:"
    echo "  [1] Start Web App immediately (uses high-accuracy ImageNet mapping)"
    echo "  [2] Train local model first (takes 10-30 minutes, requires TensorFlow)"
    echo "--------------------------------------------------------------"
    echo
    read -p "Enter your choice (1 or 2, default is 1): " choice
    
    if [ "$choice" = "2" ]; then
        echo "[INFO] Starting training..."
        python3 model/train_model.py
        if [ $? -ne 0 ]; then
            echo "[ERROR] Training failed!"
            exit 1
        fi
    else
        echo "[INFO] Skipping training. Running web app directly using ImageNet mapping..."
    fi
fi

echo
echo "[INFO] Starting Flask web application..."
echo "Open your browser and go to: http://localhost:5000"
echo
python3 app.py
